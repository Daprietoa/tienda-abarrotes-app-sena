from pydantic import BaseModel

# generar modelo de la tabla producto 

class Product(BaseModel):
    nombre_producto: str
    precio:float
    stock: int
    